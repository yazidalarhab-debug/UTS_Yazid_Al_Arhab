package com.farhan.profileapp;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;

import androidx.exifinterface.media.ExifInterface;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Menyimpan foto pilihan pengguna di penyimpanan internal aplikasi (diperkecil, dikoreksi rotasinya). */
public final class ImageStore {
    private ImageStore() {}

    public static File avatarFile(Context c) { return new File(c.getFilesDir(), "avatar.jpg"); }
    public static File coverFile(Context c)  { return new File(c.getFilesDir(), "cover.jpg"); }

    public static File albumDir(Context c) {
        File d = new File(c.getFilesDir(), "album");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /** Foto album, terbaru dulu. */
    public static List<File> albumFiles(Context c) {
        List<File> out = new ArrayList<>();
        File[] files = albumDir(c).listFiles((dir, name) -> name.endsWith(".jpg"));
        if (files != null) Collections.addAll(out, files);
        Collections.sort(out, (a, b) -> b.getName().compareTo(a.getName()));
        return out;
    }

    /** Blocking: panggil dari thread background. */
    public static boolean saveFromUri(Context c, Uri uri, File dest, int maxPx) {
        try {
            ContentResolver cr = c.getContentResolver();

            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = cr.openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false;

            int sample = 1;
            while (Math.max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxPx) sample *= 2;

            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            Bitmap bmp;
            try (InputStream in = cr.openInputStream(uri)) {
                bmp = BitmapFactory.decodeStream(in, null, opts);
            }
            if (bmp == null) return false;

            int rotation = 0;
            try (InputStream in = cr.openInputStream(uri)) {
                int o = new ExifInterface(in).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                if (o == ExifInterface.ORIENTATION_ROTATE_90) rotation = 90;
                else if (o == ExifInterface.ORIENTATION_ROTATE_180) rotation = 180;
                else if (o == ExifInterface.ORIENTATION_ROTATE_270) rotation = 270;
            } catch (IOException ignored) {
                // tanpa EXIF: anggap normal
            }

            float scale = Math.min(1f, (float) maxPx / Math.max(bmp.getWidth(), bmp.getHeight()));
            Bitmap out = bmp;
            if (rotation != 0 || scale < 1f) {
                Matrix m = new Matrix();
                m.postRotate(rotation);
                m.postScale(scale, scale);
                out = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
            }

            File tmp = new File(dest.getParentFile(), dest.getName() + ".tmp");
            try (FileOutputStream fo = new FileOutputStream(tmp)) {
                out.compress(Bitmap.CompressFormat.JPEG, 88, fo);
            }
            if (dest.exists()) dest.delete();
            return tmp.renameTo(dest);
        } catch (IOException | SecurityException | OutOfMemoryError e) {
            return false;
        }
    }

    /** Muat file dengan ukuran kira-kira reqPx (sisi terpanjang). Null jika tidak ada/rusak. */
    public static Bitmap load(File f, int reqPx) {
        if (f == null || !f.exists()) return null;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        if (o.outWidth <= 0) return null;
        int sample = 1;
        while (Math.max(o.outWidth, o.outHeight) / (sample * 2) >= reqPx) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        try {
            return BitmapFactory.decodeFile(f.getAbsolutePath(), opts);
        } catch (OutOfMemoryError e) {
            return null;
        }
    }
}
