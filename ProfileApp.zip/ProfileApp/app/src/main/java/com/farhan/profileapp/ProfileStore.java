package com.farhan.profileapp;

import android.content.Context;
import android.content.SharedPreferences;

/** Penyimpanan data profil lokal (SharedPreferences). */
public final class ProfileStore {
    private static final String PREFS = "profile_prefs";

    public static final String KEY_NAME = "name";
    public static final String KEY_USERNAME = "username";
    public static final String KEY_BIO = "bio";
    public static final String KEY_CONTACT = "contact";
    public static final String KEY_COUNTRY = "country";

    private ProfileStore() {}

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String get(Context c, String key) {
        return prefs(c).getString(key, defaultFor(key));
    }

    private static String defaultFor(String key) {
        switch (key) {
            case KEY_NAME:     return "M. Farhan Billyahsan";
            case KEY_USERNAME: return "farhan.billyahsan";
            case KEY_BIO:      return "Mahasiswa Sistem Informasi STIKOM Tunas Bangsa Pematangsiantar. "
                    + "Suka membangun aplikasi Android dan menganalisis data.";
            case KEY_CONTACT:  return "farhan.billyahsan@gmail.com";
            case KEY_COUNTRY:  return "Indonesia";
            default:           return "";
        }
    }
}
