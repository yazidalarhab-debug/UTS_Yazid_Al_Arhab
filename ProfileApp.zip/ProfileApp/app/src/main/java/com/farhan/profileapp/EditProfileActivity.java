package com.farhan.profileapp;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EditProfileActivity extends AppCompatActivity {

    private static final int AVATAR_PX = 512;

    private EditText etName, etUsername, etBio, etContact;
    private Spinner spCountry;
    private ImageView ivAvatar;

    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private final ActivityResultLauncher<String> pickAvatar = registerForActivityResult(
            new ActivityResultContracts.GetContent(), uri -> {
                if (uri == null) return;
                io.execute(() -> {
                    boolean ok = ImageStore.saveFromUri(
                            getApplicationContext(), uri, ImageStore.avatarFile(this), AVATAR_PX);
                    if (!ok) {
                        runOnUiThread(() -> Toast.makeText(
                                this, R.string.photo_error, Toast.LENGTH_SHORT).show());
                        return;
                    }
                    showAvatar();
                });
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        etName = findViewById(R.id.etName);
        etUsername = findViewById(R.id.etUsername);
        etBio = findViewById(R.id.etBio);
        etContact = findViewById(R.id.etContact);
        spCountry = findViewById(R.id.spCountry);
        ivAvatar = findViewById(R.id.ivAvatarEdit);

        ivAvatar.setOnClickListener(v -> pickAvatar.launch("image/*"));
        io.execute(this::showAvatar);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.countries, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCountry.setAdapter(adapter);

        // Isi form hanya saat pertama dibuka; setelah rotasi, Android memulihkan isian pengguna.
        if (savedInstanceState == null) {
            etName.setText(ProfileStore.get(this, ProfileStore.KEY_NAME));
            etUsername.setText(ProfileStore.get(this, ProfileStore.KEY_USERNAME));
            etBio.setText(ProfileStore.get(this, ProfileStore.KEY_BIO));
            etContact.setText(ProfileStore.get(this, ProfileStore.KEY_CONTACT));
            String country = ProfileStore.get(this, ProfileStore.KEY_COUNTRY);
            for (int i = 0; i < adapter.getCount(); i++) {
                if (country.contentEquals(adapter.getItem(i))) {
                    spCountry.setSelection(i);
                    break;
                }
            }
        }

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnSave).setOnClickListener(v -> save());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdown();
    }

    /** Background: muat foto profil lalu tampilkan di UI thread. */
    private void showAvatar() {
        Bitmap b = ImageStore.load(ImageStore.avatarFile(this), 400);
        if (b == null) return;
        runOnUiThread(() -> {
            if (!isFinishing() && !isDestroyed()) ivAvatar.setImageBitmap(b);
        });
    }

    private void save() {
        String name = etName.getText().toString().trim();
        String username = etUsername.getText().toString().trim();
        String contact = etContact.getText().toString().trim();

        if (name.isEmpty()) {
            etName.setError(getString(R.string.err_name));
            etName.requestFocus();
            return;
        }
        if (username.isEmpty() || username.contains(" ")) {
            etUsername.setError(getString(R.string.err_username));
            etUsername.requestFocus();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(contact).matches()) {
            etContact.setError(getString(R.string.err_email));
            etContact.requestFocus();
            return;
        }

        ProfileStore.prefs(this).edit()
                .putString(ProfileStore.KEY_NAME, name)
                .putString(ProfileStore.KEY_USERNAME, username)
                .putString(ProfileStore.KEY_BIO, etBio.getText().toString().trim())
                .putString(ProfileStore.KEY_CONTACT, contact)
                .putString(ProfileStore.KEY_COUNTRY, String.valueOf(spCountry.getSelectedItem()))
                .apply();

        Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show();
        finish();
    }
}
